export default function StatusCard({ product, status }) {
  return (
    <div className={`p-4 rounded-xl bg-white/10 border-l-4 border-${status.color}-500`}>
      <h2 className="text-lg font-semibold">{product.name}</h2>
      <p>Barcode: {product.barcode}</p>
      <p>Expiry: {product.expiry}</p>
      <p>Status: <span className={`text-${status.color}-400 font-bold`}>{status.label}</span></p>
    </div>
  );
}
