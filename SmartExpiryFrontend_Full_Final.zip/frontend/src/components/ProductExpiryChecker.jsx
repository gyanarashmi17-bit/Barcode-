import { useState } from 'react';
import StatusCard from './StatusCard';

export default function ProductExpiryChecker() {
  const [products, setProducts] = useState(() => {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : [];
  });

  const [input, setInput] = useState({ name: '', barcode: '', expiry: '' });

  const addProduct = () => {
    if (!input.name || !input.barcode || !input.expiry) return;
    const newProducts = [...products, input];
    setProducts(newProducts);
    localStorage.setItem('products', JSON.stringify(newProducts));
    setInput({ name: '', barcode: '', expiry: '' });
  };

  const calculateStatus = (expiryDate) => {
    const diff = Math.ceil((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24));
    if (diff < 0) return { label: 'Expired', color: 'red' };
    if (diff <= 7) return { label: 'Near Expiry', color: 'yellow' };
    return { label: 'Fresh', color: 'green' };
  };

  return (
    <div className="space-y-6">
      <div className="space-x-3">
        <input placeholder="Product Name" value={input.name} onChange={e => setInput({ ...input, name: e.target.value })} className="p-2 rounded text-black" />
        <input placeholder="Barcode" value={input.barcode} onChange={e => setInput({ ...input, barcode: e.target.value })} className="p-2 rounded text-black" />
        <input type="date" value={input.expiry} onChange={e => setInput({ ...input, expiry: e.target.value })} className="p-2 rounded text-black" />
        <button onClick={addProduct} className="bg-blue-600 px-4 py-2 rounded hover:bg-blue-700">Add</button>
      </div>

      {products.map((p, i) => {
        const status = calculateStatus(p.expiry);
        return <StatusCard key={i} product={p} status={status} />;
      })}
    </div>
  );
}
