import ProductExpiryChecker from './components/ProductExpiryChecker';

export default function App() {
  return (
    <div className="text-center p-8">
      <h1 className="text-3xl font-bold mb-6">Smart Expiry Management System</h1>
      <ProductExpiryChecker />
    </div>
  );
}
